create
    definer = root@localhost procedure sp_ingresar_usuario(IN p_nombre_usuario varchar(30), IN p_contrasena varchar(20))
BEGIN

    INSERT INTO usuarios (nombre_usuario, contrasena) 
    VALUES (p_nombre_usuario, p_contrasena);

END;

