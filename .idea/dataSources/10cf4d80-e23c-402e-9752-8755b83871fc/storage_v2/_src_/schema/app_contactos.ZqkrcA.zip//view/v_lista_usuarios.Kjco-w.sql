create view v_lista_usuarios as
(
select `app_contactos`.`usuarios`.`id_usuario`     AS `id_usuario`,
       `app_contactos`.`usuarios`.`email_usuario`  AS `email_usuario`,
       `app_contactos`.`usuarios`.`nombre_usuario` AS `nombre_usuario`,
       `app_contactos`.`usuarios`.`contrasena`     AS `contrasena`,
       `app_contactos`.`usuarios`.`fecha_creacion` AS `fecha_creacion`,
       `app_contactos`.`usuarios`.`tipo_usuario`   AS `tipo_usuario`
from `app_contactos`.`usuarios`);

